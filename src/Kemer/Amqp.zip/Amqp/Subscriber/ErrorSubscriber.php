<?php
namespace Kemer\Amqp\Subscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\EventDispatcher\Event;
use Kemer\Amqp\Broker;
use Kemer\Amqp;

class ErrorSubscriber implements EventSubscriberInterface
{
    /**
     * @var bool Whether no further event listeners should be triggered
     */
    private $stopPropagation = true;

    private $callback;

    /**
     * {@inheritDoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            'Exception.#' => [
                ['onException', 1001]
            ],
            'RuntimeException' => [
                ['onException', 1001]
            ],
            'LogicException' => [
                ['onException', 1001]
            ],
        ];
    }

    /**
     * @param Broker $broker
     * @param bool $stopPropagation
     */
    public function __construct(callback $callback, $stopPropagation = true)
    {
        $this->callback = $callback;
        $this->stopPropagation = $stopPropagation;
    }

    /**
     * On dispatch event listener - called on any event
     *
     * @param Event $event
     * @param string $eventName
     * @return void
     */
    public function onException(Event $event, $eventName)
    {
        if ($event instanceof Amqp\ErrorEvent) {
            $event->getEvent()->addHeader("x-exception", [
                "message" => $event->getException()->getMessage(),
                "code" => $event->getException()->getCode(),
                "class" => get_class($event->getException()),
            ]);
            $callback = $this->callback;
            $callback($event->getEvent());
            if ($this->stopPropagation) {
                $event->stopPropagation();
            }
        }
    }
}
