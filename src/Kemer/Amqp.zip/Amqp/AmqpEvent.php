<?php
namespace Kemer\Amqp;

class AmqpEvent extends Event
{

}
