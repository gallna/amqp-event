<?php
namespace Kemer\Amqp;

use Symfony\Component\EventDispatcher\EventDispatcherInterface;

interface DispatcherInterface extends EventDispatcherInterface
{

}
