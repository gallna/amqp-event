<?php
namespace Kemer\Amqp;

class ErrorEvent extends Event
{
    /**
     * @var \Exception
     */
    public $exception;

    /**
     * @var Event
     */
    public $event;

    /**
     * @var string
     */
    public $name;

    /**
     * @param AMQPEnvelope $envelope
     * @param AMQPQueue $queue
     */
    public function __construct(Event $event, \Exception $exception, $name = null)
    {
        $this->name = $name;
        $this->event = $event;
        $this->exception = $exception;
    }

    /**
     * Returns Exception triggered this event
     *
     * @return Event
     */
    public function getName()
    {
        if (!$this->name) {
            $this->name = str_replace("\\", ".", get_class($this->getException()));
        }
        return $this->name;
    }

    /**
     * Returns Exception triggered this event
     *
     * @return Event
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Returns Exception triggered this event
     *
     * @return Exception|null
     */
    public function getException()
    {
        return $this->exception;
    }
}
