<?php
namespace Kemer\Amqp\Exceptions;

class NotConsumedException extends \DomainException
{

}
