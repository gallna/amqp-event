<?php
namespace Kemer\Amqp;

/**
 * This flag tells the server how to react if a message cannot be routed to a queue.
 * Specifically, if mandatory is set and after running the bindings the message was placed on zero queues then the message is returned to the sender (with a basic.return). If mandatory had not been set under the same circumstances the server would silently drop the message.
 */
class MandatoryEvent extends PublishEvent
{
    /**
     * Returns channel
     *
     * @return object
     */
    public function getFlags()
    {
        return AMQP_MANDATORY;
    }
}
