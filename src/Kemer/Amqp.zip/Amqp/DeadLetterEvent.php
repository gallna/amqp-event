<?php
namespace Kemer\Amqp;

class DeadLetterEvent extends Event
{
    const SEND = "dead.letter.send";

    /**
     * @var \Exception
     */
    public $exception;

    /**
     * @var ConsumeEvent
     */
    public $event;

    /**
     * @param AMQPEnvelope $envelope
     * @param AMQPQueue $queue
     */
    public function __construct(ConsumeEvent $event, \Exception $exception = null)
    {
        $this->event = $event;
        $this->exception = $exception;
    }

    /**
     * Returns Exception triggered this event
     *
     * @return ConsumeEvent
     */
    public function getConsumeEvent()
    {
        return $this->event;
    }

    /**
     * Returns Exception triggered this event
     *
     * @return Exception|null
     */
    public function getException()
    {
        return $this->exception;
    }

    /**
     * Returns attributes send to wait exchange
     *
     * @return array
     */
    public function attributes()
    {
        $headers = $this->event->getHeaders();
        $headers["x-exception"] = [
            "message" => $this->getException() ? $this->getException()->getMessage() : null,
            "code" => $this->getException() ? $this->getException()->getCode() : null,
        ];

        return [
            "app_id" => $this->event->getAppId(),
            "user_id" => $this->event->getUserId(),
            "message_id" => $this->event->getMessageId(),
            "priority" => $this->event->getPriority(),
            "type" => $this->event->getType(),
            "reply_to" => $this->event->getReplyTo(),
            "timestamp" => $this->event->getTimeStamp(),
            "delivery_mode" => $this->event->getDeliveryMode(),
            "content_type" => $this->event->getContentType(),
            "expiration" => $this->event->getExpiration(),
            "headers" => $headers,
        ];
    }
}
