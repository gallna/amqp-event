<?php
namespace Kemer\Amqp\Facade;

use Kemer\Amqp;

class Postpone
{
    /**
     * @var Broker
     */
    protected $broker;

    /**
     * @param Broker $broker
     */
    public function __construct(Amqp\Broker $broker)
    {
        $this->broker = $broker;
    }

    /**
     * On dispatch event listener - called on any event
     *
     * @param AmqpEvent $event
     * @return void
     */
    public function postpone(AmqpEvent $event)
    {
        $event->setHeader("x-retry-count", $event->getHeader("x-retry-count", 10) - 1);
        $event->setExpiration(10000);
        // Checks if message was expired or retried too many times
        if ($event->getHeader("x-retry-count") > 0) {
            $exchange = $this->getExchange($event->getExchangeName());
            $this->getQueue($event->getExchangeName())
                ->bind($exchange->getName(), $event->getRoutingKey());
            $exchange->publish(
                $event->getBody(),
                $event->getRoutingKey(),
                AMQP_MANDATORY,
                $event->attributes()
            );
        }
    }

    /**
     * Creates wait queue
     *
     * @return AMQPQueue
     */
    private function getQueue($name)
    {
        $queue = $this->broker->queue(AMQP_DURABLE, $name.".wait");
        $queue->setArgument("x-dead-letter-exchange", $name);
        $queue->declareQueue();
        return $queue;
    }

    /**
     * Creates wait exchange
     *
     * @return AMQPExchange
     */
    private function getExchange($name)
    {
        return $this->broker->declareExchange(AMQP_DURABLE, $name.".wait", AMQP_EX_TYPE_DIRECT);
    }
}
