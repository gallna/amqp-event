<?php
namespace Kemer\Amqp\Publisher;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\EventDispatcher\Event;
use Kemer\Amqp\Broker;
use Kemer\Amqp;

class DefaultPublisher implements EventSubscriberInterface
{
    /**
     * @var Broker
     */
    protected $broker;

    /**
     * @var AMQPExchange
     */
    protected $defaultExchange;

    /**
     * @var bool Whether no further event listeners should be triggered
     */
    private $stopPropagation = true;

    /**
     * {@inheritDoc}
     */
    public static function getSubscribedEvents()
    {
        return [
            '#' => [
                ['onDispatch', 1000]
            ]
        ];
    }

    /**
     * @param Broker $broker
     * @param AMQPExchange $defaultExchange
     * @param bool $stopPropagation
     */
    public function __construct(Broker $broker, \AMQPExchange $defaultExchange = null, $stopPropagation = true)
    {
        $this->broker = $broker;
        $this->defaultExchange = $defaultExchange;
        $this->stopPropagation = $stopPropagation;
    }

    /**
     * Creates if needed and returns default exchange
     *
     * @return AMQPExchange
     */
    protected function getDefaultExchange()
    {
        if (!$this->defaultExchange) {
            $this->defaultExchange = $this->broker->exchange();
        }
        return $this->defaultExchange;
    }

    /**
     * On dispatch event listener - called on any event
     * AMQP_MANDATORY: When publishing a message, the message must be routed to a valid queue. If it is not, an error will be returned.
     *  if the client publishes a message with the "mandatory" flag set to an exchange of "direct" type which is not bound to a queue.
     * AMQP_IMMEDIATE: When publishing a message, mark this message for immediate processing by the broker.
     *      REMOVED from rabbitmq > 3-0 http://www.rabbitmq.com/blog/2012/11/19/breaking-things-with-rabbitmq-3-0
     * @param Event $event
     * @param string $eventName
     * @return void
     */
    public function onDispatch(Event $event, $eventName)
    {
        if ($event instanceof Amqp\PublishEvent) {
            if ($event->getExchangeName() !== null) {
                // publish to named exchange
                $exchange = $this->broker->exchange(null, $event->getExchangeName());
            } else {
                // depending on set default exchange - publish directly to queue
                // or to default-exchange
                $exchange = $this->getDefaultExchange();
            }

            $exchange->publish(
                $event->getBody(),
                $eventName,
                $event->getFlags(),
                $event->jsonSerialize()
            );

            if ($this->stopPropagation) {
                $event->stopPropagation();
            }
        }
    }
}
