<?php
namespace Kemer\Amqp;

/**
 * stub class representing AMQPEnvelope from pecl-amqp
 */
trait PublishTrait
{
    private $exchangeName;
    private $routingKey;
    private $mandatory;
    private $immediate;

    public static function fromEnvelope(\AMQPEnvelope $envelope)
    {
        $self = new static();
        $self->setAppId($envelope->getAppId());
        $self->setBody($envelope->getBody());
        $self->setContentEncoding($envelope->getContentEncoding());
        $self->setContentType($envelope->getContentType());
        $self->setCorrelationId($envelope->getCorrelationId());
        $self->setDeliveryMode($envelope->getDeliveryMode());
        $self->setDeliveryTag($envelope->getDeliveryTag());
        $self->setExchangeName($envelope->getExchangeName());
        $self->setExpiration($envelope->getExpiration());
        $self->setHeaders($envelope->getHeaders());
        $self->setMessageId($envelope->getMessageId());
        $self->setPriority($envelope->getPriority());
        $self->setReplyTo($envelope->getReplyTo());
        $self->setRoutingKey($envelope->getRoutingKey());
        $self->setTimeStamp($envelope->getTimeStamp());
        $self->setType($envelope->getType());
        $self->setUserId($envelope->getUserId());
        $self->setRedelivery($envelope->isRedelivery());
        return $self;
    }

    /**
     * Get the exchange name on which the message was published.
     *
     * @param the message was published.
     */
    public function setExchangeName($exchangeName)
    {
        $this->exchangeName = $exchangeName;
        return $this;
    }

    /**
     * Get the exchange name on which the message was published.
     *
     * @return string The exchange name on which the message was published.
     */
    public function getExchangeName()
    {
        return $this->exchangeName;
    }


    /**
     * Get the routing key of the message.
     *
     * @return string The message routing key.
     */
    public function getRoutingKey()
    {
        return $this->routingKey;
    }

    /**
     * Get the routing key of the message.
     *
     * @param The message routing key.
     */
    public function setRoutingKey($routingKey)
    {
        $this->routingKey = $routingKey;
        return $this;
    }
}


